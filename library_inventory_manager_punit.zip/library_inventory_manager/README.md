
# Library Inventory Manager

A mini-project for managing library books using Python OOP, JSON persistence, and CLI.

## Features
- Add, issue, return books
- JSON file storage
- Logging + exception handling
- Modular package structure
